<?php
define('ADMIN_DIR', 'admin');
$rootDir = str_replace(ADMIN_DIR, '', dirname(__FILE__));
require ($rootDir . '/includes/init.php');
?>