<?php
define('CDN_URL', ROOT_URL . 'files/');
define('CDN_CSS_VERSION', 201401271445);
define('CDN_JS_VERSION', 201401271445);