<?php
// DEBUG MODE
define('DEBUG_MODE', TRUE);
define('OUTPUT_ERR_TEXT', 'bad! err!');

define('SUPER_ADMIN_USER_NAME', 'admin');
define('SUPER_ADMIN_PASSWORD', 'admin123');


define('ORDER_SN_ROOT', 'D');
define('ORDER_SN_LENGTH', '6');
define('ORDER_SEQUENCE_NAME', 'order_list_sn');

