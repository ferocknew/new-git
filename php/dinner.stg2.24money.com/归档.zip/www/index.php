<?php
include '../app/init.php';
base_ctrl::index_main();
